const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),{WebSocketServer}=require('ws');
const PORT=process.env.PORT||3000,rooms=new Map();
const INITIAL="rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR";
const code=()=>{let x;do{x=crypto.randomBytes(3).toString('hex').toUpperCase()}while(rooms.has(x));return x};
const send=(w,m)=>w.readyState===1&&w.send(JSON.stringify(m));
const broadcast=(r,m,except)=>r.players.forEach(p=>p.ws!==except&&send(p.ws,m));
const color=p=>p==='.'?null:(p===p.toUpperCase()?'w':'b');
const enemy=c=>c==='w'?'b':'w';
function makeState(){return {board:INITIAL,turn:'w',castle:'KQkq',ep:-1,half:0,full:1};}
function attacked(s,sq,by){const b=s.board,r=Math.floor(sq/8),c=sq%8;
  const pawn=by==='w'?'P':'p'; const pr=by==='w'?r+1:r-1;
  for(const dc of[-1,1]){const rr=pr,cc=c+dc;if(rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===pawn)return true}
  const n=by==='w'?'N':'n'; for(const [dr,dc] of[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]){let rr=r+dr,cc=c+dc;if(rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===n)return true}
  const k=by==='w'?'K':'k'; for(const dr of[-1,0,1])for(const dc of[-1,0,1])if(dr||dc){let rr=r+dr,cc=c+dc;if(rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===k)return true}
  const lines=(pieces,dirs)=>{for(const [dr,dc] of dirs){let rr=r+dr,cc=c+dc;while(rr>=0&&rr<8&&cc>=0&&cc<8){const p=b[rr*8+cc];if(p!=='.')return pieces.includes(p);rr+=dr;cc+=dc}}return false};
  if(lines(by==='w'?'BQ':'bq',[[-1,-1],[-1,1],[1,-1],[1,1]]))return true;
  if(lines(by==='w'?'RQ':'rq',[[-1,0],[1,0],[0,-1],[0,1]]))return true;
  return false;
}
function inCheck(s,c){const k=s.board.indexOf(c==='w'?'K':'k');return k<0||attacked(s,k,enemy(c));}
function pseudo(s,from){const b=s.board,p=b[from],c=color(p),r=Math.floor(from/8),x=from%8,out=[];if(!c)return out;
 const add=(rr,cc)=>{if(rr<0||rr>7||cc<0||cc>7)return false;const j=rr*8+cc;if(b[j]==='.')out.push({from,to:j});else{if(color(b[j])!==c)out.push({from,to:j});return false}return true};
 if(p.toLowerCase()==='p'){const d=c==='w'?-1:1,start=c==='w'?6:1,rr=r+d;if(rr>=0&&rr<8&&b[rr*8+x]==='.'){out.push({from,to:rr*8+x});if(r===start&&b[(r+2*d)*8+x]==='.')out.push({from,to:(r+2*d)*8+x})}for(const dc of[-1,1]){const cc=x+dc;if(rr>=0&&rr<8&&cc>=0&&cc<8){const j=rr*8+cc;if(b[j]!=='.'&&color(b[j])!==c)out.push({from,to:j});if(j===s.ep)out.push({from,to:j,ep:true})}}}
 else {let ds=[];if('bq'.includes(p.toLowerCase()))ds.push([-1,-1],[-1,1],[1,-1],[1,1]);if('rq'.includes(p.toLowerCase()))ds.push([-1,0],[1,0],[0,-1],[0,1]);if(p.toLowerCase()==='n')ds=[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];if(p.toLowerCase()==='k')ds=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];for(const [dr,dc] of ds){let rr=r+dr,cc=x+dc;while(rr>=0&&rr<8&&cc>=0&&cc<8){if(!add(rr,cc)||p.toLowerCase()==='n'||p.toLowerCase()==='k')break;rr+=dr;cc+=dc}}
  if(p.toLowerCase()==='k'&&!inCheck(s,c)){const row=c==='w'?7:0;if(from===row*8+4){if(s.castle.includes(c==='w'?'K':'k')&&b[row*8+5]==='.'&&b[row*8+6]==='.'&&!attacked(s,row*8+5,enemy(c))&&!attacked(s,row*8+6,enemy(c)))out.push({from,to:row*8+6,castle:'K'});if(s.castle.includes(c==='w'?'Q':'q')&&b[row*8+1]==='.'&&b[row*8+2]==='.'&&b[row*8+3]==='.'&&!attacked(s,row*8+3,enemy(c))&&!attacked(s,row*8+2,enemy(c)))out.push({from,to:row*8+2,castle:'Q'})}}
 }
 return out;
}
function apply(s,m,promo){let n={...s,board:s.board,castle:s.castle,ep:-1,half:s.half+1,full:s.full+(s.turn==='b'?1:0)};let a=n.board.split(''),p=a[m.from],c=color(p),target=a[m.to];a[m.from]='.';if(m.ep){const cap=m.to+(c==='w'?8:-8);a[cap]='.'}if(m.castle){const row=c==='w'?7:0;if(m.to===row*8+6){a[row*8+5]=a[row*8+7];a[row*8+7]='.'}else{a[row*8+3]=a[row*8];a[row*8]='.'}}
 if(p.toLowerCase()==='p'&&(m.to<8||m.to>=56))p=(promo||'Q').toUpperCase()=== 'N'?'N':(promo||'Q').toUpperCase();if(c==='b')p=p.toLowerCase();a[m.to]=p;n.board=a.join('');if(p.toLowerCase()==='p'||target!=='.'||m.ep)n.half=0;if(p.toLowerCase()==='k'){n.castle=n.castle.replace(c==='w'?/[KQ]/g:/[kq]/g,'')}if(m.from===63||m.to===63)n.castle=n.castle.replace('K','');if(m.from===56||m.to===56)n.castle=n.castle.replace('Q','');if(m.from===7||m.to===7)n.castle=n.castle.replace('k','');if(m.from===0||m.to===0)n.castle=n.castle.replace('q','');if(p.toLowerCase()==='p'&&Math.abs(m.to-m.from)===16)n.ep=(m.from+m.to)/2;n.turn=enemy(s.turn);return n;}
function legalMoves(s,from){const c=color(s.board[from]);if(c!==s.turn)return [];return pseudo(s,from).filter(m=>!inCheck(apply(s,m,'Q'),c));}
function allMoves(s){let out=[];for(let i=0;i<64;i++)if(color(s.board[i])===s.turn)out.push(...legalMoves(s,i));return out;}
function result(s){const moves=allMoves(s);if(moves.length)return null;return inCheck(s,s.turn)?(s.turn==='w'?'0-1':'1-0'):'1/2-1/2';}
function status(s){const r=result(s);if(r)return {over:true,result:r,reason:inCheck(s,s.turn)?'Мат':'Пат'};if(s.half>=100)return {over:true,result:'1/2-1/2',reason:'Правило 50 ходов'};return {over:false,result:null,reason:null};}
const server=http.createServer((req,res)=>{let p=new URL(req.url,'http://x').pathname;if(p.startsWith('/game/'))p='/index.html';if(p==='/')p='/index.html';let f=path.join(__dirname,'public',p);fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('Not found')}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(d)})});
const wss=new WebSocketServer({server});
wss.on('connection',ws=>{let r=null,p=null;ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
 if(m.type==='create'){let c=code();r={code:c,state:makeState(),players:[]};rooms.set(c,r);p={ws,color:'w',name:String(m.name||'Игрок').slice(0,24)};r.players.push(p);return send(ws,{type:'room',code:c,color:'w',state:r.state,players:r.players.map(x=>({color:x.color,name:x.name})),status:status(r.state)})}
 if(m.type==='join'){r=rooms.get(String(m.code||'').toUpperCase());if(!r)return send(ws,{type:'error',message:'Комната не найдена'});if(r.players.length>=2)return send(ws,{type:'error',message:'Комната уже заполнена'});p={ws,color:'b',name:String(m.name||'Игрок').slice(0,24)};r.players.push(p);let ps=r.players.map(x=>({color:x.color,name:x.name}));send(ws,{type:'room',code:r.code,color:'b',state:r.state,players:ps,status:status(r.state)});return broadcast(r,{type:'players',players:ps},ws)}
 if(m.type==='reset'&&r){r.state=makeState();return broadcast(r,{type:'state',state:r.state,status:status(r.state)})}
 if(m.type==='move'&&r&&p&&p.color===r.state.turn&&!status(r.state).over){let f=m.from,t=m.to;if(!Number.isInteger(f)||!Number.isInteger(t)||f<0||f>63||t<0||t>63)return;const legal=legalMoves(r.state,f).find(x=>x.to===t);if(!legal)return send(ws,{type:'error',message:'Недопустимый ход'});r.state=apply(r.state,legal,m.promotion);let st=status(r.state);broadcast(r,{type:'state',state:r.state,status:st,last:{from:f,to:t}})}});
 ws.on('close',()=>{if(r&&p){r.players=r.players.filter(x=>x!==p);broadcast(r,{type:'left',message:'Соперник вышел'});if(!r.players.length)rooms.delete(r.code)}})});
server.listen(PORT,()=>console.log('Chess Forge on '+PORT));
